import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Diferenciais } from "@/components/Diferenciais";
import { Portfolio } from "@/components/Portfolio";
import { Servicos } from "@/components/Servicos";
import { FAQ } from "@/components/FAQ";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <Hero />
      <Diferenciais />
      <Portfolio />
      <Servicos />
      <FAQ />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;
