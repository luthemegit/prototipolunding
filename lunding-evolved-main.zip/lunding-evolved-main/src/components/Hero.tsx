import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "./ui/button";

export const Hero = () => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 hero-gradient" />
      <div className="spotlight left-1/4 top-1/4 animate-glow-pulse" />
      <div
        className="spotlight right-1/4 bottom-1/4 animate-glow-pulse"
        style={{ animationDelay: "-1.5s" }}
      />

      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(hsl(var(--primary)) 1px, transparent 1px),
                             linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />
      </div>

      {/* Floating Orbs */}
      <motion.div
        className="absolute w-72 h-72 rounded-full bg-primary/10 blur-3xl"
        animate={{
          x: [0, 50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ left: "10%", top: "20%" }}
      />
      <motion.div
        className="absolute w-96 h-96 rounded-full bg-accent/10 blur-3xl"
        animate={{
          x: [0, -40, 0],
          y: [0, 40, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ right: "5%", bottom: "10%" }}
      />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary mb-8"
          >
            <Sparkles size={16} />
            <span className="text-sm font-medium">
              Agenda para 2026 ABERTA!
            </span>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-tight mb-8"
          >
            A Internet é o Seu <span className="text-gradient">Palco.</span>
            <br />
            Que Tipo de Espetáculo{" "}
            <span className="relative">
              <span className="text-gradient">Você Quer Dar?</span>
              <motion.span
                className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-primary to-accent rounded-full"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.8, delay: 1 }}
              />
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-12"
          >
            Todo grande show exige uma produção impecável. Eu sou o{" "}
            <span className="text-foreground font-medium italic">
              freelancer
            </span>{" "}
            que constrói os bastidores digitais para que o seu negócio tenha uma
            apresentação profissional e sem falhas a cada clique.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button variant="hero" size="xl" className="group">
              O que isso Significa?
              <ArrowRight className="transition-transform group-hover:translate-x-1" />
            </Button>
            <Button variant="glass" size="xl">
              Ver Portfólio
            </Button>
          </motion.div>
        </div>

        {/* Floating Devices Mockup */}
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-20 relative"
        >
          <div className="relative max-w-4xl mx-auto">
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent blur-3xl rounded-3xl" />

            {/* Devices Container */}
            <div className="relative flex items-end justify-center gap-4">
              {/* Tablet */}
              <motion.div
                className="floating hidden sm:block"
                style={{ animationDelay: "-2s" }}
              >
                <div className="w-48 md:w-64 h-64 md:h-80 bg-card rounded-2xl border border-border/50 shadow-2xl overflow-hidden">
                  <div className="h-full p-3 flex flex-col gap-2">
                    <div className="w-full h-2 bg-secondary rounded-full" />
                    <div className="flex-1 bg-secondary/50 rounded-xl flex items-center justify-center">
                      <div className="w-16 h-8 bg-primary/30 rounded-lg" />
                    </div>
                    <div className="flex gap-2">
                      <div className="flex-1 h-8 bg-primary rounded-lg" />
                      <div className="flex-1 h-8 bg-secondary rounded-lg" />
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Main Monitor */}
              <motion.div className="floating-delayed">
                <div className="w-72 md:w-96 h-56 md:h-72 bg-card rounded-2xl border border-border/50 shadow-2xl overflow-hidden glow-effect">
                  <div className="h-full p-4 flex flex-col gap-3">
                    <div className="flex gap-2">
                      <div className="w-3 h-3 rounded-full bg-destructive/50" />
                      <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                      <div className="w-3 h-3 rounded-full bg-green-500/50" />
                    </div>
                    <div className="w-full h-3 bg-secondary rounded-full" />
                    <div className="flex-1 bg-secondary/30 rounded-xl p-4 flex flex-col gap-2">
                      <div className="w-3/4 h-3 bg-primary/40 rounded" />
                      <div className="w-1/2 h-3 bg-muted rounded" />
                      <div className="flex-1 flex items-center justify-center">
                        <div className="w-24 h-12 bg-gradient-to-r from-primary to-accent rounded-lg" />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Phone */}
              <motion.div
                className="floating hidden sm:block"
                style={{ animationDelay: "-4s" }}
              >
                <div className="w-32 md:w-40 h-56 md:h-72 bg-card rounded-3xl border border-border/50 shadow-2xl overflow-hidden">
                  <div className="h-full p-2 flex flex-col gap-2">
                    <div className="w-12 h-1 bg-border mx-auto rounded-full mt-1" />
                    <div className="flex-1 bg-secondary/50 rounded-xl flex items-center justify-center">
                      <div className="w-12 h-6 bg-accent/30 rounded-lg" />
                    </div>
                    <div className="w-full h-10 bg-primary rounded-xl" />
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1 h-2 bg-primary rounded-full"
          />
        </motion.div>
      </motion.div>
    </section>
  );
};
